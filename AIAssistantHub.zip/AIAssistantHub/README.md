# Clon de ChatGPT Plus con Agentes de IA

Una aplicación que replica la interfaz de ChatGPT Plus con agentes de IA con memoria y capacidades de automatización.

## Características

- 🤖 Múltiples agentes de IA con diferentes personalidades y capacidades
- 💬 Interfaz de chat en tiempo real
- 🌙 Modo claro/oscuro
- 📱 Diseño responsivo para móviles y escritorio
- ⚡ Automatizaciones configurables
- 🧠 Sistema de memoria para los agentes

## Tecnologías

- Frontend: React, TailwindCSS, Shadcn/UI
- Backend: Node.js con Express
- Comunicación en tiempo real: WebSockets (ws)
- Manejo de estado: React Query
- Enrutamiento: Wouter
- Validación de datos: Zod

## Instalación y uso local

1. Clona el repositorio:
   ```bash
   git clone <tu-repositorio>
   cd <tu-proyecto>
   ```

2. Instala las dependencias:
   ```bash
   npm install
   ```

3. Inicia el servidor de desarrollo:
   ```bash
   npm run dev
   ```

4. Abre [http://localhost:5000](http://localhost:5000) en tu navegador.

## Despliegue en Netlify

### Prerrequisitos

- Cuenta en [Netlify](https://www.netlify.com/)
- Repositorio en GitHub, GitLab o Bitbucket

### Pasos para desplegar

1. **Subir el código a un repositorio Git**:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin <url-de-tu-repositorio>
   git push -u origin main
   ```

2. **Acceder a Netlify**:
   - Inicia sesión en tu cuenta de Netlify
   - Haz clic en "New site from Git"
   - Selecciona el proveedor de Git donde está tu repositorio
   - Autoriza a Netlify para acceder a tu repositorio
   - Selecciona el repositorio de tu proyecto

3. **Configurar el despliegue**:
   - **Rama a desplegar**: `main` (o la que uses)
   - **Comando de construcción**: `npm run build`
   - **Directorio de publicación**: `dist`
   - **Variables de entorno**:
     - `VITE_NETLIFY`: `true`

4. **Hacer clic en "Deploy site"**

### Funciones de Netlify

La aplicación usa las Funciones Serverless de Netlify para manejar el backend. Esto significa que:

- Las rutas de la API serán accesibles a través de `/.netlify/functions/api/...`
- Las redirecciones en `netlify.toml` configuran automáticamente que las rutas `/api/*` se dirijan a las funciones de Netlify
- No es necesario tener un servidor Express separado

### Limitaciones de Netlify

- **WebSockets**: Netlify no admite WebSockets en sus funciones serverless gratuitas. La aplicación usa un enfoque de polling para simular la funcionalidad en producción.
- **Limitaciones de ejecución**: Las funciones serverless tienen un tiempo límite de ejecución (10 segundos en el plan gratuito).

## Alternativas de despliegue

Si necesitas soporte completo para WebSockets, considera estas alternativas:

### Vercel

Vercel ofrece una experiencia similar a Netlify pero con mejor soporte para WebSockets a través de Edge Functions.

### Railway

Railway proporciona un entorno más completo donde puedes ejecutar tanto tu frontend como backend, incluyendo WebSockets, bases de datos, etc.

### Digital Ocean App Platform

Una solución completa que admite WebSockets y ofrece escalabilidad para aplicaciones más grandes.

## Licencia

[MIT](LICENSE)